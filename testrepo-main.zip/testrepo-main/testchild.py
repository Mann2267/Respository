print 'I'm Child'
